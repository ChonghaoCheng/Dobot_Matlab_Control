%notice
%word_1 = "Please input control value for next step";
word_e = "current error on step ";
word_e_sum = "Total error in process is: ";

%plane config
width = 20;
longth = 40;

%line_position
y_truth = longth/2;
x_truth = width;

%draw working space
figure;
yline(y_truth,'r','Goal');
xline(x_truth,'b','Width');
ylim([10,30]);
xlim([0,25]);
hold on

%robot_initialization
y_r = [20];
x_r = [0];
X_robo = [x_r,y_r];

%Sensor_initialization
x_o = zeros(10,1);
y_o = zeros(10,1);
theta_o = zeros(10,1);
X_obv = [x_o,y_o,theta_o];

%control_value_initialization
y_u = zeros(10,1);
x_u = zeros(10,1);
U = [x_u,y_u];
error = 0;

%control and update robot position
int8 step;
for step =1:10
    X_obv(step,:) = Get_Obv(X_obv,step); 
    U(step,:) = Cal_control(X_obv,X_robo(step,:),step);%y_truth,);

    %U(step,:) = Cal_control_input();
    X_r_current = X_robo(end,:);
    X_r_next = U(step,:);
    plot(X_robo(:,1),X_robo(:,2),'o-');
    X_robo(end+1,:) = X_r_next;

    %collect error in each step
    error(step) = Cal_error_sep(y_truth,X_r_current,X_r_next,width);
    disp(word_e+step+': ');
    disp(error(step));

    %if cut through break
    if X_r_next(1)> width || X_r_next(1)<0
        break
    end
end

plot(X_robo(:,1),X_robo(:,2),'o-');
hold off

error_sum = sum(error);

%if not cut through，the left area will be all counted into error
if X_r_next(1)<width
    rest = (width-X_r_next(1))*y_truth;
    error_sum = error_sum+rest;
end

%disp(error)
disp(word_e_sum+ error_sum)









