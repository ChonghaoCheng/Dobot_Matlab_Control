function [Obversation] = Get_Obv(X_obv,step)
%GET_OBV 此处显示有关此函数的摘要
%   此处显示详细说明
    X_obv_pre =[0,0,0];
    if step ~= 1
        X_obv_pre = X_obv(step-1,:);
    end

    x_o = X_obv_pre(1)+0;
    y_o = X_obv_pre(2)+rand(1);
    theta_o = X_obv_pre(3)+normrnd(1,0.1,1);

    Obversation = [x_o,y_o,theta_o];
end

