function [Control_Value] = Cal_control(Observation,RobotPosition,step)%,Goal,error)
    
    X_obs = Observation(step,1);
    Y_obs = Observation(step,2);
    Theta_obs = Observation(step,3);
    
    X_obs_pre = 0;
    Y_obs_pre =0;
    Theta_obs_pre = 0;
    
    if step ~=1
        X_obs_pre = Observation(step-1,1);
        Y_obs_pre = Observation(step-1,2);
        Theta_obs_pre = Observation(step-1,3);
    end
    
    X_rp = RobotPosition(1);
    Y_rp = RobotPosition(2);



    theta = Theta_obs - Theta_obs_pre;
    x = X_obs- X_obs_pre;
    y = Y_obs - Y_obs_pre;

    
    Rot = [cos(theta) -sin(theta);
            sin(theta) cos(theta)];
    
    control = -Rot*[x;y];


    X_ctrl = X_rp + control(1);
    Y_ctrl = Y_rp + 0.1*control(2);
    
    Control_Value = [X_ctrl,Y_ctrl];

end

