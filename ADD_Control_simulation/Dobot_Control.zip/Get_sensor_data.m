function [Disturbance] = Get_sensor_data()%step)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
    %Sensor ground truth value
    %Sensor is attached at the center of the plane
    %Sensor value means it's relative pose to it's previous position
    
    % X_sensor = zeros(1,20);
    % Y_sensor = zeros(1,20);
    % Theta_sensor = zeros(1,20);
    % Disturbance=[X_sensor',Y_sensor',Theta_sensor'];
    
    % Y_sensor = [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0]';
    % X_sensor = zeros(20,1);
    % Theta_sensor = zeros(20,1);
    %  Disturbance=[X_sensor,Y_sensor,Theta_sensor];
    % 
    X_sensor = zeros(20,1);
    Y_sensor = zeros(20,1);

    Theta_sensor = 0.0025:0.0025:0.05 ;
    Disturbance=[X_sensor,Y_sensor,Theta_sensor'];

    
    % X_sensor = [1,2,-1,-2,1,-1,2,-2,0.1,-0.1]';
    % Y_sensor = [1,2,-1,-2,1,-1,2,-2,0.1,-0.1]';
    % Theta_sensor = [0,0,0,0,0,0,0,0,0,0]';
    % 
    % sensor=randn(3,20);
    % X_sensor = sensor(1,:)/20;
    % Y_sensor = sensor(2,:)/20;   
    % Theta_sensor = sensor(3,:)/40;
    % Disturbance=[X_sensor',Y_sensor',Theta_sensor'];

    % X_sensor = [1,2,-1,-2,1,-1,2,-2,0.1,-0.1]';
    % Y_sensor = [1,2,-1,-2,1,-1,2,-2,0.1,-0.1]';
    % Theta_sensor = [0.1,0,0,0,0,0,0,0,0,0]';

    % x_gt= X_sensor(step);
    % y_gt= Y_sensor(step);
    % theta_gt= Theta_sensor(step);

    %EM_sensor = rossubscriber(topic);
    % X_sensor = EM_sensor.data.X
    % Y_sensor = EM_sensor.data.Y
    % Theta_sensor = EM_sensor.data.Theta

     % Disturbance=[X_sensor,Y_sensor,Theta_sensor];
    
end

