function [Obversation] = Get_Obv(X_obv,step)
%GET_OBV 此处显示有关此函数的摘要
%   此处显示详细说明
    % X_obv_pre =[0,0,0];
    % if step ~= 1
    %     X_obv_pre = X_obv(step-1,:);
    % end

    % x_o = X_obv_pre(1)+0;
    % y_o = X_obv_pre(2)+rand(1);
    % theta_o = X_obv_pre(3)+normrnd(1,0.1,1);

    Sensor_Data = Get_sensor_data(step);
    x_gt = Sensor_Data(1);
    y_gt = Sensor_Data(2);
    theta_gt = Sensor_Data(3);

    x_o = x_gt;
    y_o = y_gt;
    theta_o =theta_gt;

    Obversation = [x_o,y_o,theta_o];
    
end

