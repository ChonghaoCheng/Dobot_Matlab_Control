function [Obversation] = Get_Obv(Ground_Truth,step)

    Sensor_Data = Ground_Truth(step,:);
    x_gt = Sensor_Data(1);
    y_gt = Sensor_Data(2);
    theta_gt = Sensor_Data(3);

    x_o = x_gt;
    y_o = y_gt;
    theta_o =theta_gt;

    Obversation = [x_o,y_o,theta_o];
    
end

