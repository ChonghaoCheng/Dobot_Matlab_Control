clc;
clear all;
close all;

%sensor ground truth value

% X_sensor = [0,0,0,0,0,0,0,0,0,0]';
% Y_sensor = [0,0,0,0,0,0,0,0,0,0]';
% Theta_sensor = [0,0,0,0,0,0,0,0,0,0]';

Y_sensor = [1,0,1,0,1,0,1,0,1,0]';
X_sensor = [0,0,0,0,0,0,0,0,0,0]';
Theta_sensor = [0,0,0,0,0,0,0,0,0,0]';

% X_sensor = [0,0,0,0,0,0,0,0,0,0]';
% Y_sensor = [0,0,0,0,0,0,0,0,0,0]';
% Theta_sensor = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]';

%X_sensor = [1,2,-1,-2,1,-1,2,-2,0.1,-0.1]';
%Y_sensor = [1,2,-1,-2,1,-1,2,-2,0.1,-0.1]';
%Theta_sensor = [0,0,0,0,0,0,0,0,0,0]';

%X_sensor = [0.1,0.2,-0.1,-0.2,0.1,-0.1,0.2,-0.2,0.1,-0.1]';
%Y_sensor = [0.1,0.2,-0.1,0,0.1,-0.1,0.2,-0.2,0.1,-0.1]';
%Theta_sensor = [0.1,0.2,0.3,-0.1,-0.2,0,0,0,0,0]';

Ground_Truth = [X_sensor,Y_sensor,Theta_sensor];

%Notation List
%word_1 = "Please input control value for next step";
word_e = "current error on step ";
word_e_sum = "Total error in process is: ";

%plane config
width = 20;
longth = 40;

%line_position
x_truth = width;
y_truth = longth/2;
x= 0:2:x_truth;
y= 0:4:longth;

Target_line =([1,0;0,0]*[x;y]+[0;20])';
%Target_line =@(x,y) [0,0;0,0]*[x;y]+[0;20];

%draw working space 
figure;
%yline(y_truth,'r','Goal');
xline(x_truth,'b','Width');
ylim([0,40]);
xlim([0,25]);
hold on

%Robot__position_initialization
y_r = [20];
x_r = [0];
X_robo = [x_r,y_r];
X_robo_plane = X_robo;
% Robot_step_size = 2;

%Sensor_initialization
x_o = [0];
y_o = [0];
theta_o = [0];
X_obv = [x_o,y_o,theta_o];

%control_value_initialization
y_u = zeros(10,1);
x_u = zeros(10,1);
Control_value = [x_u,y_u];
error = 0;