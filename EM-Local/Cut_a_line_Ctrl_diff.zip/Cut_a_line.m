%set up initial values
run Config.m
plot(Target_line(:,1),Target_line(:,2),"b*--");
hold on;

%control and update robot position
int8 step;
for step =1:10

    X_obv(end+1,:) = Get_Obv(Ground_Truth,step); 

    Control_value(step,:) = Cal_control(Target_line,X_obv,X_robo,step);%y_truth,);

    % Control_value(step,:) = Cal_control_input();

    X_r_current = X_robo(end,:);
    X_r_next = X_r_current + Control_value(step,:);
    X_robo(end+1,:) = X_r_next;
    X_robo_plane(end+1,:) = Robot_pose_projection(X_obv(step+1,:),X_r_next);
    
    error(step) = Cal_step_error(Target_line(step,2),Target_line(step+1,2), ...
        X_robo_plane(step,:),X_robo_plane(step+1,:),width,y_truth);

    
    plot(X_robo(:,1),X_robo(:,2),'gv-');
    plot(X_robo_plane(:,1),X_robo_plane(:,2),'ro-');
    hold on;

    disp(word_e+step+': ');
    disp(error(step));

    %if cut through break
    if X_robo_plane(step,1)>= width
       break
    end

end


% plot(Target_line(:,1),Target_line(:,2),"b*--");
% plot(X_robo(:,1),X_robo(:,2),'gv-');
% plot(X_robo_plane(:,1),X_robo_plane(:,2),'ro-');

hold off

error_sum = sum(error);

%if not cut through，the left area will be all counted into error
if X_robo_plane(end,1)<width
    rest = (width-X_r_next(1))*y_truth;
    error_sum = error_sum+rest;
end

%disp(error)
disp(word_e_sum+ error_sum)









